using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class BulletMove : MonoBehaviour
{
    [SerializeField]
    private GameManager gameManager = null;
    [Header("�̵� �ӵ�")]
    [SerializeField]
    private float speed = 10;
    void Awake()
    {
        gameManager = FindObjectOfType<GameManager>();
    }

    void Update()
    {
        transform.Translate(Vector2.right * speed * Time.deltaTime);
        if (transform.position.x > gameManager.MaxPosition.x)
            Destroy(gameObject);
    }
}
