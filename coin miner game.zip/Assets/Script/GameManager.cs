﻿using System.Collections;
using UnityEngine;
using UnityEngine.UI;

public class GameManager : MonoBehaviour
{    
    public Vector2 MinPosition { get; private set; }
    public Vector2 MaxPosition { get; private set; }

    [Header("적 프리팹")]
    [SerializeField]
    private GameObject[] enemyPrefab = null;
    [SerializeField]
    private GameObject linePrefab = null;

    public float time = 0;
    public int line;

    public float upPos;
    public float downPos;
    public Canvas canvas;
    private void Awake()
    {
        canvas = FindObjectOfType<Canvas>();
        time = -225;
        MinPosition = new Vector2(-14f, 8f);
        MaxPosition = new Vector2(14f, 8f);
        StartCoroutine(SpawnRX470());
        StartCoroutine(SpawnRX580());
        StartCoroutine(SpawnRXVega64());
        StartCoroutine(SpawnRX5700());
        StartCoroutine(SpawnRX5700XT());
        StartCoroutine(Time());
        StartCoroutine(SpawnLine());
    }
    private IEnumerator Time()
    {
        while (true)
        {
            if (time < -100)
            {
                float spawnDelay = Random.Range(6f, -8f);
                time += upPos + downPos;
                yield return new WaitForSeconds(0.02f);
                time += spawnDelay;
            }
            else
            {
                time = time - 32f;
                yield return new WaitForSeconds(0.02f);
            }
        }
    }
    public IEnumerator Up()
    {
        upPos = 24f;
        yield return new WaitForSeconds(0.02f);
        upPos = 0;
    }
    public IEnumerator Down()
    {
        downPos = -24f;
        yield return new WaitForSeconds(0.02f);
        downPos = 0;
    }
    public void EnemyDead()
    {
        StartCoroutine(Up());
    }
    public void EnemyDead2()
    {
        StartCoroutine(Down());
    }
    private IEnumerator SpawnRX470()
    {
        float randomY = Random.Range(MinPosition.y, MaxPosition.y);
        float spawnDelay = Random.Range(2f, 4f);
        while (true)
        {
            for (int i = 0; i < 6; i++)
            {
                Instantiate(enemyPrefab[0], new Vector2(10f, randomY), Quaternion.identity);
                yield return new WaitForSeconds(0.2f);
            }

            yield return new WaitForSeconds(spawnDelay);
        }
    }
    private IEnumerator SpawnRX580()
    {
        float randomY = Random.Range(MinPosition.y, MaxPosition.y);
        float spawnDelay = Random.Range(2f, 5f);
        while (true)
        {
            yield return new WaitForSeconds(spawnDelay);
            for (int i = 0; i < 6; i++)
            {
                Instantiate(enemyPrefab[1], new Vector2(10f, randomY), Quaternion.identity);
                yield return new WaitForSeconds(0.2f);
            }

            yield return new WaitForSeconds(spawnDelay);
        }
    }
    private IEnumerator SpawnRXVega64()
    {
        float randomY = Random.Range(MinPosition.y, MaxPosition.y);
        float spawnDelay = Random.Range(2f, 4f);
        while (true)
        {
            yield return new WaitForSeconds(spawnDelay*2);
            for (int i = 0; i < 2; i++)
            {
                Instantiate(enemyPrefab[2], new Vector2(10f, randomY), Quaternion.identity);
                yield return new WaitForSeconds(0.2f);
            }

            yield return new WaitForSeconds(spawnDelay);
        }
    }
    private IEnumerator SpawnRX5700()
    {
        float randomY = Random.Range(MinPosition.y, MaxPosition.y);
        float spawnDelay = Random.Range(2f, 4f);
        while (true)
        {
            yield return new WaitForSeconds(spawnDelay*2);
            for (int i = 0; i < 2; i++)
            {
                Instantiate(enemyPrefab[3], new Vector2(10f, randomY), Quaternion.identity);
                yield return new WaitForSeconds(0.2f);
            }

            yield return new WaitForSeconds(spawnDelay);
        }
    }
    private IEnumerator SpawnRX5700XT()
    {
        float randomY = Random.Range(MinPosition.y, MaxPosition.y);
        float spawnDelay = Random.Range(2f, 4f);
        while (true)
        {
            yield return new WaitForSeconds(spawnDelay*3);
            for (int i = 0; i < 2; i++)
            {
                Instantiate(enemyPrefab[4], new Vector2(10f, randomY), Quaternion.identity);
                yield return new WaitForSeconds(0.2f);
            }

            yield return new WaitForSeconds(spawnDelay);
        }
    }
    private IEnumerator SpawnLine()
    {
        while (true)
        {
                Instantiate(linePrefab, new Vector3(12f, 0f + time / 30f,1), Quaternion.identity);
                yield return new WaitForSeconds(0.1f);
        }
    }
}
