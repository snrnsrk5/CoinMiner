using System.Collections;
using UnityEngine;

public class PlayerMove : MonoBehaviour
{
    [Header("�̵� �ӵ�")]
    [SerializeField]
    private float speed = 2f;
    [Header("�Ѿ� ������")]
    [SerializeField]
    private GameObject bulletPrefab = null;
    [Header("�Ѿ� �߻簣��")]
    [SerializeField]
    private float bulletDelay = 0.5f;

    private Vector2 targetPosition = Vector2.zero;
    private SpriteRenderer spriteRenderer = null;
    [SerializeField]
    private Transform bulletPosition1 = null;
    [SerializeField]
    private Transform bulletPosition2 = null;
    [SerializeField]
    private Transform bulletPosition3 = null;
    private void Awake()
    {
        spriteRenderer = GetComponent<SpriteRenderer>();
        StartCoroutine(Fire());
    }

    private void Update()
    {
        if (Input.GetMouseButton(0))
        {
            targetPosition = Camera.main.ScreenToWorldPoint(Input.mousePosition);
            transform.position = Vector2.MoveTowards(transform.position, targetPosition, speed * Time.deltaTime);
        }
    }

    private IEnumerator Fire()
    {
        GameObject bullet1 = null;
        GameObject bullet2 = null;
        GameObject bullet3 = null;
        while (true)
        {
            bullet1 = Instantiate(bulletPrefab, bulletPosition1);
            bullet2 = Instantiate(bulletPrefab, bulletPosition2);
            bullet3 = Instantiate(bulletPrefab, bulletPosition3);
            bullet1.transform.SetParent(null);
            bullet2.transform.SetParent(null);
            bullet3.transform.SetParent(null);
            yield return new WaitForSeconds(bulletDelay);
        }
    }
    private bool isDead = false;
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (isDead == true) return;
        if (collision.tag == "Enemy")
        {
            isDead = true;
            StartCoroutine(Dead());
        }
    }

    private IEnumerator Dead()
    {
        for (int i = 0; i < 5; i++)
        {
            spriteRenderer.enabled = false;
            yield return new WaitForSeconds(0.1f);
            spriteRenderer.enabled = true;
            yield return new WaitForSeconds(0.1f);
        }
        isDead = false;
    }
}
